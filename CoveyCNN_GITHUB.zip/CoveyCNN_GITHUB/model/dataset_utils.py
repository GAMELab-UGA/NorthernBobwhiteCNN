import numpy as np
import os
import pandas as pd
import librosa
import soundfile as sf


def load_one(file, offset, config):

    try:
        x, sr = librosa.load(file, sr=config['sr'], mono=False, offset=offset, duration=config['duration'])
    except:
        print("FAIL READING rec", file)
    if (x.ndim == 2):
        x = x[0,:] # left channel

    x -= np.mean(x) # remove DC

    return x, sr


def write_one(outfile, x, sr, subtype='PCM_16'):
    sf.write(outfile, x, sr, subtype=subtype)


def save_presence(filename, data_dir, output_dir, config):
    df = pd.read_csv(filename, sep="\t")
    if df.empty:
        print("Warning: no labels found in {}".format(os.path.basename(filename)))
        return

    assert not df.isnull().values.any(), '{} contains null values'.format(filename)
    
    file = os.path.join(data_dir, df['Begin File'].iloc[0])
    recording_site = os.path.basename(file).split('_')[0]
    label_site = os.path.basename(filename).split('_')[0]
    assert (recording_site == label_site), '{} has inconsistent Begin File'.format(filename)

    file_duration = librosa.get_duration(filename=file)

    # subset presence data
    df = df[df['Background Noise'] < 1]
    
    # calculate midpoint of labelled calls
    df['Mid Time (s)'] = 0.5 * (df['Begin Time (s)'] + df['End Time (s)'])
    df['Mid Freq (Hz)'] = 0.5 * (df['Low Freq (Hz)'] + df['High Freq (Hz)'])
    
    # save a df subset representing a 'clip_duration' window around around each call
    for index, row in df.iterrows(): # tqdm(, total=df.shape[0], leave=False):
        name = row['Begin File'].replace('.wav', '')
        unique_id = row['UniqueID']
        midpoint = row['Mid Time (s)']
        peak_power = row['Peak Power (dB)']
        
        df_subset = df[np.abs(df['Mid Time (s)'] - midpoint) < (0.5 * config['duration'])].copy()
        
        # load clip
        offset = max(0, midpoint - 0.5 * config['duration'])
        x, sr = load_one(file, offset, config)
        
        # check for empty audio clip
        if (np.std(x) < np.finfo(float).eps):
            print("Warning: skipping blank audio clip\n- file: {}\n- offset: {}".format(row["Begin File"], offset))
            continue
        
        # call centroids
        centroids = []
        for index_subset, row_subset in df_subset.iterrows():
            centroids.append((row_subset['Mid Time (s)']-offset, row_subset['Mid Freq (Hz)']))
        
        centroids = np.asarray(centroids)
        
        # presence/absence, offset in ms, peak power (dB), filename
        myTuple = ("1", str(int(1000 * offset)), str(int(np.round(peak_power))), name)
        outfile = os.path.join(output_dir, '_'.join(myTuple))
        np.savez(outfile, x=x, sr=sr, y=centroids)

def save_absence(filename, data_dir, output_dir, rng, config):

    df = pd.read_csv(filename, sep="\t")
    if df.empty:
        print("Warning: no labels found in {}".format(os.path.basename(filename)))
        return

    file = os.path.join(data_dir, df['Begin File'].iloc[0])
    file_duration = librosa.get_duration(filename=file)

    mask = np.ones(int(file_duration//config['duration']))
    for index, row in df.iterrows():
        if (row['Background Noise'] == 0):
            name = row['Begin File'].replace('.wav', '')
            begin_time = max(row['Begin Time (s)'] - config['pad'], 0)
            end_time = min(row['End Time (s)'] + config['pad'], file_duration)
            start_idx = int(begin_time//config['duration'])
            end_idx = int(end_time//config['duration'])
            mask[start_idx:end_idx+1] = 0

    mask_sum = np.sum(mask)
    num_valid_clips = int(mask_sum)
    sample_size = min(num_valid_clips, config['num_absence'])
    if (sample_size < config['num_absence']):
        print('Warning: {} background clips saved from {}'.format(sample_size, file))

    if (sample_size > 0):
        p = mask / mask_sum
        offsets = config['duration'] * rng.choice(np.arange(len(mask)), size=sample_size, replace=False, p=p)
        for offset in offsets:
            # load audio clip
            x, sr = load_one(file, offset, config)

            # check for empty audio clip
            if (np.std(x) < np.finfo(float).eps):
                print("Warning: skipping blank audio clip\n- file: {}\n- offset: {}".format(row["Begin File"], offset))
                continue
            
            centroids = np.empty(0)
        
            # presence/absence, offset in ms, peak power (dB), filename
            myTuple = ("0", str(int(1000 * offset)), str(0), name)
            outfile = os.path.join(output_dir, '_'.join(myTuple))
            np.savez(outfile, x=x, sr=sr, y=centroids)              
    else:
        print("Warning: no absence clips saved from {}".format(os.path.basename(file)))
