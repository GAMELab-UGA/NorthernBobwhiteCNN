"""Defines the neural network, losss function and metrics"""

from sklearn.metrics import average_precision_score, precision_score, recall_score, fbeta_score
import timm
import torch
import torchaudio as ta
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
from torch.nn.parameter import Parameter
import numpy as np

from typing import Optional, List
from timm import create_model


# https://github.com/qubvel/segmentation_models.pytorch/blob/master/segmentation_models_pytorch/fpn/model.py
class Interpolate(nn.Module):
    def __init__(self, scale_factor):
        super(Interpolate, self).__init__()
        self.interp = nn.functional.interpolate
        self.scale_factor = scale_factor
        
    def forward(self, x):
        x = self.interp(x, scale_factor=self.scale_factor, mode="bilinear", align_corners=False)
        return x


class SegmentationHead(nn.Sequential):

    def __init__(self, in_channels, out_channels, kernel_size=3, upsampling=1):
        conv2d = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding='same', padding_mode='replicate')
        nn.init.zeros_(conv2d.bias)
        upsampling = Interpolate(scale_factor=upsampling) if upsampling > 1 else nn.Identity()
        super().__init__(conv2d, upsampling)


# add GeM pooling option
class ClassificationHead(nn.Sequential):

    def __init__(self, in_channels, classes, pooling="avg", dropout=0.2):
        if pooling not in ("max", "avg"):
            raise ValueError("Pooling should be one of ('max', 'avg'), got {}.".format(pooling))
        pool = nn.AdaptiveAvgPool2d(1) if pooling == 'avg' else nn.AdaptiveMaxPool2d(1)
        flatten = nn.Flatten()
        dropout = nn.Dropout(p=dropout, inplace=True) if dropout else nn.Identity()
        linear = nn.Linear(in_channels, classes, bias=True)
        nn.init.zeros_(linear.bias)
        super().__init__(pool, flatten, dropout, linear)


class Conv3x3GNSiLU(nn.Module):
    def __init__(self, in_channels, out_channels, upsample=False, bias=False):
        super().__init__()
        self.upsample = upsample
        # BSConv
        self.block = nn.Sequential(
            nn.Conv2d(
                in_channels, out_channels, 1, bias=False
            ),
            nn.Conv2d(
                out_channels, out_channels, 3, stride=1, padding='same', groups=out_channels, padding_mode='replicate', bias=bias
            ),
            nn.GroupNorm(32, out_channels),
            nn.SiLU(inplace=True),
        )

    def forward(self, x):
        x = self.block(x)
        if self.upsample:
            #https://discuss.pytorch.org/t/what-we-should-use-align-corners-false/22663
            x = F.interpolate(x, scale_factor=2, mode="bilinear", align_corners=False)
        return x


class FPNBlock(nn.Module):
    def __init__(self, pyramid_channels, skip_channels):
        super().__init__()
        self.skip_conv = nn.Conv2d(skip_channels, pyramid_channels, kernel_size=1)
        nn.init.zeros_(self.skip_conv.bias)

    def forward(self, x, skip=None):
        x = F.interpolate(x, scale_factor=2, mode="nearest")
        skip = self.skip_conv(skip)
        x = x + skip
        return x


class SegmentationBlock(nn.Module):
    def __init__(self, in_channels, out_channels, n_upsamples=0):
        super().__init__()

        blocks = [Conv3x3GNSiLU(in_channels, out_channels, upsample=bool(n_upsamples))]

        if n_upsamples > 1:
            for _ in range(1, n_upsamples):
                blocks.append(Conv3x3GNSiLU(out_channels, out_channels, upsample=True))

        self.block = nn.Sequential(*blocks)

    def forward(self, x):
        return self.block(x)


class MergeBlock(nn.Module):
    def __init__(self, policy):
        super().__init__()
        if policy not in ["add", "cat"]:
            raise ValueError(
                "`merge_policy` must be one of: ['add', 'cat'], got {}".format(
                    policy
                )
            )
        self.policy = policy

    def forward(self, x):
        if self.policy == 'add':
            return sum(x)
        elif self.policy == 'cat':
            return torch.cat(x, dim=1)
        else:
            raise ValueError(
                "`merge_policy` must be one of: ['add', 'cat'], got {}".format(self.policy)
            )


class FPNDecoder(nn.Module):
    def __init__(
            self,
            encoder_channels,
            encoder_depth=4,
            pyramid_channels=256,
            segmentation_channels=128,
            dropout=0.2,
            merge_policy="add",
    ):
        super().__init__()

        self.out_channels = segmentation_channels if merge_policy == "add" else segmentation_channels * 4
        if encoder_depth < 3:
            raise ValueError("Encoder depth for FPN decoder cannot be less than 3, got {}.".format(encoder_depth))

        encoder_channels = encoder_channels[::-1]
        encoder_channels = encoder_channels[:encoder_depth + 1]

        self.p5 = nn.Conv2d(encoder_channels[0], pyramid_channels, kernel_size=1)
        self.p4 = FPNBlock(pyramid_channels, encoder_channels[1])
        self.p3 = FPNBlock(pyramid_channels, encoder_channels[2])
        self.p2 = FPNBlock(pyramid_channels, encoder_channels[3])

        self.seg_blocks = nn.ModuleList([
            SegmentationBlock(pyramid_channels, segmentation_channels, n_upsamples=n_upsamples)
            for n_upsamples in [3, 2, 1, 0]
        ])

        self.merge = MergeBlock(merge_policy)
        self.dropout = nn.Dropout2d(p=dropout, inplace=True)

    def forward(self, features: List[torch.Tensor]):
        c2, c3, c4, c5 = features[-4:]

        p5 = self.p5(c5)
        p4 = self.p4(p5, c4)
        p3 = self.p3(p4, c3)
        p2 = self.p2(p3, c2)

        feature_pyramid = [seg_block(p) for seg_block, p in zip(self.seg_blocks, [p5, p4, p3, p2])]
        x = self.merge(feature_pyramid)
        x = self.dropout(x)

        return x

class FPN(nn.Module):
    """FPN is a fully convolution neural network for image semantic segmentation.
    
    http://presentations.cocodataset.org/COCO17-Stuff-FAIR.pdf
    
    """
    
    def __init__(
            self,
            backbone='resnet34',
            backbone_kwargs=None,
            backbone_indices=None,
            encoder_depth=4,
            decoder_pyramid_channels: int = 256,
            decoder_segmentation_channels: int = 128,
            decoder_merge_policy: str = "add",
            decoder_dropout: float = 0.2,
            in_channels: int = 1,
            classes: int = 1,
            upsampling: int = 2,
            aux_params: Optional[dict] = None,
    ):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        # NOTE some models need different backbone indices specified based on the alignment of features
        # and some models won't have a full enough range of feature strides to work properly.
        encoder = create_model(
            backbone, features_only=True, out_indices=backbone_indices, in_chans=in_channels,
            pretrained=True, **backbone_kwargs)
        encoder_channels = encoder.feature_info.channels()
        
        self.encoder = encoder
        self.decoder = FPNDecoder(encoder_channels=encoder_channels,
            encoder_depth=encoder_depth,
            pyramid_channels=decoder_pyramid_channels,
            segmentation_channels=decoder_segmentation_channels,
            dropout=decoder_dropout,
            merge_policy=decoder_merge_policy,)

        self.segmentation_head = SegmentationHead(self.decoder.out_channels, classes, kernel_size=3, upsampling=upsampling)

        if aux_params is not None:
            self.classification_head = ClassificationHead(
                in_channels=encoder_channels[-1], **aux_params
            )
        else:
            self.classification_head = None

    def forward(self, x: torch.Tensor):
        features = self.encoder(x)
        decoder_output = self.decoder(features)
        
        masks = self.segmentation_head(decoder_output)
        
        if self.classification_head is not None:
            labels = self.classification_head(features[-1])
            return masks, labels
        
        return masks


class Net(nn.Module):

    def __init__(self, params):
        super(Net, self).__init__()

        self.params = params

        self.mel_spec = ta.transforms.MelSpectrogram(
            sample_rate=params.sample_rate,
            n_fft=params.window_size,
            win_length=params.window_size,
            hop_length=params.hop_length,
            f_min=params.fmin,
            f_max=params.fmax,
            pad=0,
            n_mels=params.n_mels,
            power=params.power,
            normalized=False,
            norm='slaney',
        )

        self.amplitude_to_db = ta.transforms.AmplitudeToDB(top_db=params.top_db)

        self.backbone = FPN(backbone=params.backbone,
                            backbone_indices=(0,1,2,3),
                            encoder_depth=4,
                            in_channels=2,
                            classes=1,
                            decoder_pyramid_channels=params.decoder_pyramid_channels,
                            decoder_segmentation_channels=params.decoder_segmentation_channels,
                            decoder_merge_policy=params.decoder_merge_policy,
                            decoder_dropout=params.dropout_rate,
                            aux_params=None)

        self.mels = torch.nn.Parameter(torch.linspace(0,1,params.n_mels).view(1,1,-1,1), requires_grad=False)


    def forward(self, batch):
        x = batch["input"]

        with autocast(enabled=False):
            mel_power_spec = self.mel_spec(x).unsqueeze(1) # (bs, 1, mel, time)
            mel_spec = self.amplitude_to_db(mel_power_spec)
            mel_spec = (mel_spec + 80) / 80

        output_dict = {'mel_power_spec': mel_power_spec}
        output_dict['mel_spec'] = mel_spec
        
        # pad so input is divisible by 16
        time = mel_spec.shape[-1]
        extra = time % 16
        if extra > 0:
            pad = (16 - extra)
            mel_spec = F.pad(mel_spec, (0,pad,0,0), "replicate") # pad right
        
        # FreqConv (CoordConv for frequency)
        # https://www.kaggle.com/c/rfcx-species-audio-detection/discussion/220760
        x = torch.cat((mel_spec, self.mels.tile(mel_spec.shape[0],1,1,mel_spec.shape[-1])), 1)
        
        # FPN
        logits_raw = self.backbone(x)
        
        # remove any padding from output
        logits_raw = logits_raw[:,:,:,:time]
        
        # global max-pool logits
        logits = torch.flatten(logits_raw, start_dim=1).max(1)[0]

        output_dict['logits_raw'] = logits_raw
        output_dict['logits'] = logits
        return output_dict


def precision(y_true, y_scores):
    return precision_score(y_true, y_scores)


def recall(y_true, y_scores):
    return recall_score(y_true, y_scores)


def average_precision(y_true, y_scores):
    return average_precision_score(y_true, y_scores)


def fbeta(y_true, y_scores, beta=1.0):
    return fbeta_score(y_true, y_scores, beta=beta)


def loss_fn(outputs, labels, weight=None, reduction='mean'):
    return F.binary_cross_entropy_with_logits(outputs, labels, weight=weight, reduction=reduction)


# maintain all metrics required in this dictionary- these are used in the training and evaluation loops
metrics = {
    'average_precision': average_precision,
    'precision': precision,
    'recall': recall,
    'fbeta': fbeta,
}
