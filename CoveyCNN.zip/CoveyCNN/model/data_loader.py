import librosa
import numpy as np
import os
from scipy import signal
import torch
from torch.utils.data import Dataset, DataLoader, SequentialSampler


class AddBackgroundNoise():
    def __init__(self, paths='data/short_audio', beta=0.1, seed=1234):
        super().__init__()

        self.paths = librosa.util.find_files(paths, ext=['wav', 'flac'])
        self.num_files = len(self.paths)
        print("sound files available for data augmentation: {}".format(self.num_files))

        #Intialise a random number generator for reproducible experiments
        self.rng = np.random.default_rng(seed)
        self.beta = beta


    def __call__(self, x, sr, res_type='kaiser_fast'):

        # return identity
        if self.num_files == 0:
            return x, 1.0

        num_samples = len(x)
        num_seconds = x.size / sr # seconds

        # load a random soundfile
        path = self.rng.choice(self.paths)
        duration = librosa.get_duration(filename=path) # seconds

        offset = 0
        if (duration > num_seconds):
            offset = self.rng.uniform(0, duration - num_seconds)
        try:
            sound = librosa.load(path, sr, mono=True, offset=offset, duration=num_seconds, res_type=res_type)[0]
        except:
            print("FAIL READING rec", path)

        x -= np.mean(x)
        x_peak = np.max(np.abs(x))

        sound -= np.mean(sound)
        sound_peak = np.max(np.abs(sound))

        ratio = x_peak / max(sound_peak, 1e-12)
        sound *= ratio # normalise sound relative to x before mixing
        ###########
        
        # repeat the sound if shorter than input sound
        while len(sound) < num_samples:
            sound = np.concatenate((sound, sound))

        if len(sound) > num_samples:
            sound = sound[0:num_samples]

        # return a mix of the input sound and the background noise sound
        gate = self.rng.beta(self.beta, self.beta)
        gate = max(gate, 1-gate)
        x = gate * x + (1 - gate) * sound
        return x, gate


# convert centroids to segmentation mask
def centroids_to_mask(x, sr, centroids, params):
    mel_freqs = librosa.mel_frequencies(n_mels=params.n_mels, fmin=params.fmin, fmax=params.fmax, htk=True)
    n_frames = 1 + int(librosa.samples_to_frames(x.size, hop_length=params.hop_length))
    mask = np.zeros((params.n_mels, n_frames))
    for i in range(centroids.shape[0]):
        mel_bin = np.argmax(mel_freqs >= centroids[i][1])
        time = centroids[i][0]
        assert time > 0, 'time: {}'.format(time)
        frame = librosa.time_to_frames(time, sr=sr, hop_length=params.hop_length)
        mask[mel_bin, frame] = 1
    return mask


class CoveyDataset(Dataset):
    """
    A standard PyTorch definition of Dataset which defines the functions __len__ and __getitem__.
    """
    def __init__(self, data_dir, mode, params):

        #Intialise a random number generator for reproducible experiments
        self.rng = np.random.default_rng(params.seed)

        self.mode = mode
        self.params = params

        self.filenames = os.listdir(data_dir)
        self.filenames = [os.path.join(data_dir, f) for f in self.filenames if f.endswith('.npz')]
        self.labels = [float(os.path.split(filename)[-1][0]) for filename in self.filenames]

        self.mel_freqs = librosa.mel_frequencies(n_mels=params.n_mels, fmin=params.fmin, fmax=params.fmax, htk=True)

        self.mixup = None
        if (mode == 'train'):
            self.mixup = AddBackgroundNoise(params.aug_sounds_path, params.mixup_beta, params.seed)


    def __len__(self):
        return len(self.filenames)


    def __getitem__(self, idx):
        filename = self.filenames[idx]
        target = self.labels[idx]

        data = np.load(filename)
        x = data['x']
        sr = data['sr']
        centroids = data['y']

        # convert centroids to segmentation mask
        mask = centroids_to_mask(x, sr, centroids, self.params)

        if (self.mode == 'train'):
            # construct virtual training examples
            x, _ = self.mixup(x, sr)

        if (self.params.label_smoothing > 0.0):
            target = np.abs(target - self.params.label_smoothing) # [eps, 1-eps]

        feature_dict = {
            "input": torch.tensor(x),
            "target": torch.tensor(target),
            "mask": torch.tensor(mask),
        }
        return feature_dict


class UnlabelledRecordingDataset(Dataset):
    """
    A standard PyTorch definition of Dataset which defines the functions __len__ and __getitem__.
    """
    def __init__(self, path, params):

        self.params = params
        assert(params.wav_len <= 4.0)

        self.path = path
        duration = librosa.get_duration(filename=path) # seconds
        self.offsets = np.arange((duration-params.wav_len) + 1)


    def __len__(self):
        return len(self.offsets)


    def __getitem__(self, idx):

        offset = self.offsets[idx]
        duration = self.params.wav_len
        try:
            x, sr = librosa.load(self.path, sr=self.params.sample_rate, mono=False, offset=offset, duration=duration)
        except:
            print("FAIL READING rec", self.path)

        if (x.ndim == 2):
            x = x[0,:] # left channel

        # remove DC
        x -= np.mean(x)

        feature_dict = {
            "input": torch.tensor(x),
            "target": torch.tensor(0),
            "mask": torch.tensor(0),
        }
        return feature_dict


def fetch_dataloader(types, data_dir, params):
    """
    Fetches the DataLoader object for each type in types from data_dir.

    Args:
        types: (list) has one or more of 'train', 'val', 'test' depending on which data is required
        data_dir: (string) directory containing the dataset
        params: (Params) hyperparameters

    Returns:
        data: (dict) contains the DataLoader object for each type in types
    """
    dataloaders = {}

    for split in ['train', 'val', 'test']:
        if split in types:
            path = os.path.join(data_dir, "{}_npz".format(split))

            # use 'train' if training data, else use 'eval' without data augmentations
            if split == 'train':
                dl = DataLoader(CoveyDataset(path, 'train', params), batch_size=params.batch_size, shuffle=True,
                                        num_workers=params.num_workers,
                                        pin_memory=params.cuda)
            else:
                val_ds = CoveyDataset(path, 'eval', params)
                sampler = SequentialSampler(val_ds)
                dl = DataLoader(val_ds, sampler=sampler, batch_size=params.batch_size, shuffle=False,
                                num_workers=params.num_workers,
                                pin_memory=params.cuda)

            dataloaders[split] = dl

    return dataloaders
